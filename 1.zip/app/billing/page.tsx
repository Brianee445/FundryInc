'use client';

import { Suspense, useCallback, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/app/components/ui/Button';
import { Container } from '@/app/components/ui/Container';
import { VerificationBadge } from '@/app/components/ui/VerificationBadge';
import { useAuth } from '@/app/providers/AuthProvider';
import { apiGet, apiPost, ApiError } from '@/app/lib/api';
import type { VerificationTier } from '@/app/lib/types/founderProfile';
import type { BillingInterval, CheckoutResponse, PaidTier, SubscriptionStatus } from '@/app/lib/types/billing';

interface TierOption {
  tier: PaidTier;
  label: string;
  color: string; // tailwind arbitrary hex, matches VerificationBadge's palette
  perks: string[];
  monthly: number;
  /** Full-price annual total (12x monthly here — neither tier gets an automatic multi-month-free discount). */
  annual: number;
  /** Premium only: a discounted annual price shown alongside the full annual price, with the savings called out. */
  annualPromo?: number;
}

const TIERS: TierOption[] = [
  {
    tier: 'basic',
    label: 'Basic',
    color: '#F97316',
    perks: ['Up to 3 startup profiles', '5 intro messages to investors / 30 days', 'Extra profile media', 'Basic analytics'],
    monthly: 2000,
    annual: 24000,
  },
  {
    tier: 'premium',
    label: 'Premium',
    color: '#D4AF37',
    perks: [
      'Unlimited startup profiles (each stays live 90 days per publish)',
      'Unlimited intro messages to investors',
      'Blue-tick verification badge',
      'Suggested to investors',
      'Full analytics suite',
    ],
    monthly: 5000,
    annual: 60000,
    annualPromo: 50000,
  },
];

function naira(amount: number): string {
  return `₦${amount.toLocaleString('en-NG')}`;
}

function formatDate(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-NG', { year: 'numeric', month: 'long', day: 'numeric' });
}

function BillingPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();

  const [currentTier, setCurrentTier] = useState<VerificationTier>('starter');
  const [subscription, setSubscription] = useState<SubscriptionStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedInterval, setSelectedInterval] = useState<BillingInterval>('monthly');
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState('');
  const [banner, setBanner] = useState<{ tone: 'success' | 'error'; message: string } | null>(null);

  const role = user?.role === 'investor' ? 'investor' : 'founder';
  const profileEndpoint = role === 'investor' ? '/api/v1/investor-profiles/me' : '/api/v1/founder-profiles/me';

  const [hasLoaded, setHasLoaded] = useState(false);

  const loadAll = useCallback(async () => {
    setIsLoading(true);
    setError('');
    // Fetch independently rather than Promise.all — a failure on the
    // subscription call (e.g. no row yet) must never blank out a
    // successfully-fetched profile tier, which is what was making this
    // page show the stale "Starter" default while the dashboard
    // correctly showed the real tier.
    try {
      const profileData = await apiGet<{ verification_tier: VerificationTier }>(profileEndpoint);
      setCurrentTier(profileData.verification_tier);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your profile.');
    }

    try {
      const subData = await apiGet<SubscriptionStatus>('/api/v1/billing/subscription');
      setSubscription(subData);
    } catch {
      // No subscription yet (starter tier) is an expected, silent case.
      setSubscription(null);
    }

    setHasLoaded(true);
    setIsLoading(false);
  }, [profileEndpoint]);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.replace('/login');
    }
  }, [authLoading, isAuthenticated, router]);

  useEffect(() => {
    if (isAuthenticated && user) {
      loadAll();
    }
  }, [isAuthenticated, user, loadAll]);

  // Bachs redirects back here via return_url/cancel_url. That redirect is
  // UX only — the webhook is what actually grants the tier, and it can
  // land slightly before or after this page does, so we just re-fetch and
  // show a status message either way.
  useEffect(() => {
    const billingParam = searchParams.get('billing');
    if (!billingParam) return;

    if (billingParam === 'success') {
      setBanner({ tone: 'success', message: "Payment received — we're finalizing your upgrade." });
      loadAll();
    } else if (billingParam === 'cancelled') {
      setBanner({ tone: 'error', message: 'Checkout was cancelled — no charge was made.' });
    }
  }, [searchParams, loadAll]);

  async function handleUpgrade(tier: PaidTier, interval: BillingInterval) {
    setActionLoading(true);
    setError('');
    try {
      const res = await apiPost<CheckoutResponse>('/api/v1/billing/checkout', { tier, interval });
      window.location.href = res.checkout_url;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start checkout. Please try again.');
      setActionLoading(false);
    }
  }

  async function handleCancel() {
    if (!window.confirm('Cancel your subscription? Your current tier stays active until the period ends.')) {
      return;
    }
    setActionLoading(true);
    setError('');
    try {
      await apiPost('/api/v1/billing/cancel', {});
      setBanner({ tone: 'success', message: 'Your plan is set to cancel — it stays active until the period ends.' });
      await loadAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not cancel. Please try again.');
    } finally {
      setActionLoading(false);
    }
  }

  if (authLoading || isLoading || !hasLoaded) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-secondaryText">Loading...</p>
      </main>
    );
  }

  const isPaid = currentTier !== 'starter';
  const isCanceling = subscription?.status === 'canceled' && isPaid;
  const activeTierOption = TIERS.find((t) => t.tier === currentTier);

  return (
    <main className="min-h-screen bg-background py-10">
      <Container className="max-w-4xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Billing &amp; Subscription</h1>
            <p className="text-sm text-secondaryText">
              Manage your Fundry verification plan{role === 'investor' ? ' as an investor' : ''}.
            </p>
          </div>
          <Link href="/dashboard">
            <Button variant="secondary" size="sm">
              Back to dashboard
            </Button>
          </Link>
        </div>

        {banner && (
          <div
            className={`mb-6 rounded-xl border px-4 py-3 text-sm ${
              banner.tone === 'success'
                ? 'border-success/30 bg-success/10 text-success'
                : 'border-error/30 bg-error/10 text-error'
            }`}
          >
            {banner.message}
          </div>
        )}

        {/* Current status */}
        <section className="rounded-card border border-borderColor bg-cardBg p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-wide text-secondaryText">Current plan</p>
              <div className="mt-2">
                <VerificationBadge tier={currentTier} />
              </div>
            </div>

            {isPaid && subscription && (
              <div className="text-right text-sm text-secondaryText">
                <p>
                  Billing: <span className="text-primaryText">{subscription.interval === 'annual' ? 'Annual' : 'Monthly'}</span>
                </p>
                <p>
                  {isCanceling ? 'Access ends' : 'Renews'}:{' '}
                  <span className="text-primaryText">{formatDate(subscription.current_period_end)}</span>
                </p>
              </div>
            )}
          </div>

          {isPaid && (
            <div className="mt-5 border-t border-borderColor pt-5">
              {isCanceling ? (
                <p className="text-sm text-secondaryText">
                  Your plan is cancelled and won&apos;t renew. You&apos;ll keep {activeTierOption?.label ?? 'this'} access
                  until the date above.
                </p>
              ) : (
                <Button variant="secondary" size="sm" onClick={handleCancel} disabled={actionLoading}>
                  {actionLoading ? 'Cancelling…' : 'Cancel subscription'}
                </Button>
              )}
            </div>
          )}
        </section>

        {/* Plan picker */}
        <section className="mt-6">
          <div className="mb-4 flex items-center justify-center gap-2">
            {(['monthly', 'annual'] as BillingInterval[]).map((interval) => (
              <button
                key={interval}
                onClick={() => setSelectedInterval(interval)}
                className={`rounded-full border px-4 py-1.5 text-xs font-medium transition ${
                  selectedInterval === interval
                    ? 'border-primaryBlue bg-primaryBlue/10 text-primaryBlue'
                    : 'border-borderColor text-secondaryText hover:border-primaryBlue/40'
                }`}
              >
                {interval === 'monthly' ? 'Monthly' : 'Annual'}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {TIERS.map((option) => {
              const isCurrent = currentTier === option.tier;
              const isExactMatch = isCurrent && subscription?.interval === selectedInterval;
              const fullAnnual = option.annual;
              const price =
                selectedInterval === 'annual' ? option.annualPromo ?? fullAnnual : option.monthly;
              const hasPromo = selectedInterval === 'annual' && option.annualPromo !== undefined;
              const savings = hasPromo ? fullAnnual - (option.annualPromo as number) : 0;

              let buttonLabel: string;
              if (actionLoading) {
                buttonLabel = 'Redirecting…';
              } else if (isExactMatch) {
                buttonLabel = 'Current plan';
              } else if (isCurrent) {
                buttonLabel = `Switch to ${selectedInterval === 'annual' ? 'Annual' : 'Monthly'}`;
              } else if (currentTier === 'starter') {
                buttonLabel = `Upgrade — ${naira(price)}${selectedInterval === 'annual' ? '/yr' : '/mo'}`;
              } else {
                buttonLabel = `Switch to ${option.label} — ${naira(price)}${selectedInterval === 'annual' ? '/yr' : '/mo'}`;
              }

              return (
                <div
                  key={option.tier}
                  className="rounded-card border p-6"
                  style={{ borderColor: `${option.color}4D`, background: `linear-gradient(to bottom right, ${option.color}0D, transparent)` }}
                >
                  <div className="flex items-center gap-2">
                    <span style={{ color: option.color }} aria-hidden>
                      ✓
                    </span>
                    <h2 className="text-lg font-semibold">{option.label}</h2>
                    {isCurrent && <VerificationBadge tier={option.tier} className="ml-auto" />}
                  </div>

                  <p className="mt-3 flex items-baseline gap-2">
                    {hasPromo && (
                      <span className="text-base font-medium text-secondaryText line-through">{naira(fullAnnual)}</span>
                    )}
                    <span className="text-2xl font-bold text-primaryText">
                      {naira(price)}
                      <span className="text-sm font-normal text-secondaryText">
                        {selectedInterval === 'annual' ? '/yr' : '/mo'}
                      </span>
                    </span>
                  </p>
                  {hasPromo && (
                    <p className="mt-1 text-xs font-medium" style={{ color: option.color }}>
                      Save {naira(savings)} with the annual plan
                    </p>
                  )}

                  <ul className="mt-4 space-y-1.5 text-sm text-secondaryText">
                    {option.perks.map((perk) => (
                      <li key={perk} className="flex items-center gap-2">
                        <span style={{ color: option.color }} aria-hidden>
                          ✓
                        </span>
                        {perk}
                      </li>
                    ))}
                  </ul>

                  <Button
                    variant="ghost"
                    onClick={() => handleUpgrade(option.tier, selectedInterval)}
                    disabled={actionLoading || isExactMatch}
                    className="mt-5 w-full text-white hover:opacity-90 disabled:opacity-60"
                    style={{ backgroundColor: option.color }}
                  >
                    {buttonLabel}
                  </Button>
                </div>
              );
            })}
          </div>

          <p className="mt-4 text-center text-xs text-secondaryText">
            You&apos;ll be redirected to Bachs&apos; secure checkout. Cancel anytime.
          </p>
        </section>

        {error && <p className="mt-4 text-sm text-error">{error}</p>}
      </Container>
    </main>
  );
}

export default function BillingPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-background">
          <p className="text-secondaryText">Loading...</p>
        </main>
      }
    >
      <BillingPageContent />
    </Suspense>
  );
}
